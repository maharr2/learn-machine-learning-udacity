from setuptools import setup

setup(name='rm_gaussian_binomial_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['rm_gaussian_binomial_distributions'],
      author = 'Rashmi Maharjan',
      author_email = 'rashmisinghmaharjan@gmail.com',
      zip_safe=False)
